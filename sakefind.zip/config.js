// ローカル専用の設定ファイル — GitHubにはプッシュされません
// config.example.js をコピーして値を入力してください
// 警告: SUPABASE_KEY と GOOGLE_MAPS_API_KEY はブラウザに露出します。
//       Supabase の RLS と Maps API の HTTP リファラ制限で保護してください。
//       OPENAI_API_KEY / PERPLEXITY_API_KEY は本番では必ずサーバーサイド経由で使用してください。
window.SAKEFIND_CONFIG = {
  SUPABASE_URL:        'https://vgoblfarmrljkujqyogd.supabase.co',
  SUPABASE_KEY:        'sb_publishable_wJhDnc2aQ6WTEM7F5LzYDQ_ib5kov-v',
  GOOGLE_MAPS_API_KEY: 'AIzaSyDJJRTLOMcLS1OOlsjG6sDrvnUtsftKhdQ',
  ANTHROPIC_API_KEY:   '',
  OPENAI_API_KEY:      '',   // ラベル・メニュースキャン（gpt-4o）
  PERPLEXITY_API_KEY:  '',   // 日本酒情報取得（sakepedia品質）
};
